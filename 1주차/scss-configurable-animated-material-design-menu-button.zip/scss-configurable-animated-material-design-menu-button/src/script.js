$('.material--burger').on('click', function() {
		$(this).toggleClass('material--arrow');
});